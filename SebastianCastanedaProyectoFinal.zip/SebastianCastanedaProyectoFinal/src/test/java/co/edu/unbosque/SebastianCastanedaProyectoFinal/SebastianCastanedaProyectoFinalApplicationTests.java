package co.edu.unbosque.SebastianCastanedaProyectoFinal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SebastianCastanedaProyectoFinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
