package co.edu.unbosque.SebastianCastanedaProyectoFinal.controller;

import java.util.Date;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import co.edu.unbosque.SebastianCastanedaProyectoFinal.model.Compra;
import co.edu.unbosque.SebastianCastanedaProyectoFinal.model.Inventario;
import co.edu.unbosque.SebastianCastanedaProyectoFinal.model.InventarioCompra;
import co.edu.unbosque.SebastianCastanedaProyectoFinal.model.Proveedor;
import co.edu.unbosque.SebastianCastanedaProyectoFinal.repository.CompraRepository;
import co.edu.unbosque.SebastianCastanedaProyectoFinal.repository.InventarioCompraRepository;
import co.edu.unbosque.SebastianCastanedaProyectoFinal.repository.InventarioRepository;
import co.edu.unbosque.SebastianCastanedaProyectoFinal.repository.ProveedorRepository;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/inventario")
public class InventarioCompraController {
	@Autowired
	private InventarioCompraRepository daoInventarioCompraRepository;
	
	@Autowired
	private CompraRepository daoCompraRepository;
	
	@Autowired
	private InventarioRepository daoInventarioRepository;
	
	@Autowired
	private ProveedorRepository daoProveedorRepository;
	
	@PostMapping("/anadirCompra")
	public ResponseEntity<String> addCompra(@RequestParam Integer cantidad, @RequestParam Double costo_unitario,@RequestParam Integer id_compra,@RequestParam Integer id_inventario, @RequestParam String id_proveedor){
		Optional<Compra> optionalCompra = daoCompraRepository.findById(id_compra);
	    Optional<Inventario> optionalInventario = daoInventarioRepository.findById(id_inventario);
	    Optional<Proveedor> optionalProveedor = daoProveedorRepository.findByNombre(id_proveedor);
	    if (optionalCompra.isPresent() && optionalInventario.isPresent()&&optionalProveedor.isPresent()) {
	    	Compra compra = optionalCompra.get();
	    	Inventario inventario = optionalInventario.get();
	    	InventarioCompra inv = new InventarioCompra();
	    	Proveedor pro = new Proveedor();
	    	Date fc = new Date();
	    	
	    	inventario.setCantidad(inventario.getCantidad()+cantidad);
			inv.setCantidad(cantidad);
			inv.setCostoUnitario(costo_unitario);
			inventario.setCostoUnitario(costo_unitario);
			inv.setIdCompra(compra);
			inv.setIdInventario(inventario);
			compra.setFecha(fc);
			compra.setIdProveedor(pro);
			
			daoInventarioCompraRepository.save(inv);
			daoInventarioRepository.save(inventario);
			
			return ResponseEntity.status(HttpStatus.CREATED).body("Creado (201)");
	    }else {
	    	return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No Creado (201)");
	    }
	}
}
