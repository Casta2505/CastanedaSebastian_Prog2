package co.edu.unbosque.SebastianCastanedaProyectoFinal.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import co.edu.unbosque.SebastianCastanedaProyectoFinal.model.Inventario;
import co.edu.unbosque.SebastianCastanedaProyectoFinal.model.Producto;
import co.edu.unbosque.SebastianCastanedaProyectoFinal.model.Sucursal;
import co.edu.unbosque.SebastianCastanedaProyectoFinal.repository.InventarioRepository;
import co.edu.unbosque.SebastianCastanedaProyectoFinal.repository.ProductoRepository;
import co.edu.unbosque.SebastianCastanedaProyectoFinal.repository.SucursalRepository;

@Controller
@RequestMapping
public class InventarioController {
	@Autowired
	private InventarioRepository daoInventarioRepository;
	@Autowired
	private ProductoRepository daoProductoRepository;
	@Autowired
	private SucursalRepository daoSucursalRepository;
	
	@GetMapping("/ListarInventario")
	public String getEmpleados(Model model){
		List<Inventario> all = (List<Inventario>)daoInventarioRepository.findAll();
		if(all.isEmpty()) {
			return "";
		}
		model.addAttribute("all", all);
		return "index";
	}
	public String agregar(Integer cantidad, Integer id_producto, Integer id_sucursal){
		Optional<Producto> optionalProducto = daoProductoRepository.findById(id_producto);
	    Optional<Sucursal> optionalSucursal = daoSucursalRepository.findById(id_sucursal);

	    if (optionalProducto.isPresent() && optionalSucursal.isPresent()) {
	        Producto producto = optionalProducto.get();
	        Sucursal sucursal = optionalSucursal.get();
	        Inventario inventario = new Inventario();
	        inventario.setCantidad(cantidad);
	        inventario.setPrecioUnitario(producto.getCosto()*1.3);
	        inventario.setIdProducto(producto);
	        inventario.setIdSucursal(sucursal);

	        daoInventarioRepository.save(inventario);
	        return "index";
	    } else {
	        return "No Se escribio en inventario Correctamente";
	    }
	}
}
