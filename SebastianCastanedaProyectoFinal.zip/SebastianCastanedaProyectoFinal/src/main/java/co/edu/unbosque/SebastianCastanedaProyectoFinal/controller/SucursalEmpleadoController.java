package co.edu.unbosque.SebastianCastanedaProyectoFinal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import co.edu.unbosque.SebastianCastanedaProyectoFinal.model.SucursalEmpleado;
import co.edu.unbosque.SebastianCastanedaProyectoFinal.repository.SucursalEmpleadoRepository;

@Controller
@RequestMapping
public class SucursalEmpleadoController {
	@Autowired
	private SucursalEmpleadoRepository daoSucursalEmpleado;
	
	@GetMapping("/ListarEmpleados")
	public String getEmpleados(){
		List<SucursalEmpleado> all = (List<SucursalEmpleado>)daoSucursalEmpleado.findAll();
		if(all.isEmpty()) {
			return "";
		}
		return "";
	}
	
}
