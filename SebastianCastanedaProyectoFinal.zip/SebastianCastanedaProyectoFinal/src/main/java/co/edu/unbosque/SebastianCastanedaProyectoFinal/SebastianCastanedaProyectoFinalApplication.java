package co.edu.unbosque.SebastianCastanedaProyectoFinal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SebastianCastanedaProyectoFinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(SebastianCastanedaProyectoFinalApplication.class, args);
	}

}
